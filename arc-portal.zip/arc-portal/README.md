# ARC Portal

The single digital portal for **Apex Royal College (ARC)** applicants, students,
and authorized parents/guardians. This is a standalone Next.js application,
separate from the public institutional website at `https://arc.edu.ng`.

```
arc.edu.ng  --(Apply / ARC Portal / Student Portal buttons)-->  ARC Portal (this app)
                                                                       |
                                                                  Supabase
```

## Status of this build

This is a complete, deployable foundation covering the full architecture
requested: landing page, Supabase auth (login/register/forgot/reset),
role-aware route protection, the applicant multi-step application wizard
(bio-data → division → schooling → assessment → documents → payment →
review/declaration → status), the student portal (profile, academics,
results, records, fees, payments, documents, notices, calendar, support),
a parent portal restricted to explicitly linked students, a centralized
config layer for divisions/schooling/segments/assessment subjects/statuses,
a service layer separating data access from UI, and a Supabase schema with
Row Level Security.

Three things are **intentionally left as configuration points**, not bugs,
because only ARC can supply the real values:

1. **Payment provider** — `src/lib/services/payments.ts` throws until you
   wire an approved provider (Paystack/Flutterwave/Remita/etc.) with
   server-only credentials. No fake successful payments are simulated.
2. **Assessment subjects, grading (ALQ) rules, and the exact
   application/student ID numbering scheme** — see
   `src/lib/config/assessment.ts` and the `submit_application` function in
   `supabase/migrations/0001_init.sql`. Placeholder, clearly-marked
   development values are used; confirm the real rules with ARC academic
   administration before go-live.
3. **Contact information** on `/help` — set via environment variables, not
   hardcoded.

## Architecture

- **Next.js 16 App Router**, TypeScript, Tailwind CSS.
- **Supabase** for auth, Postgres, storage. `@supabase/ssr` handles secure
  server-side sessions; the service role key is used only in
  `createAdminClient()` (server-only) for privileged operations like
  authoritative ID generation.
- **`src/lib/config/`** — the single source of truth for ARC divisions,
  schooling-option rules, Institute segments, ARET assessment subjects,
  application statuses, and navigation. Nothing else in the app should
  hardcode these.
- **`src/lib/services/`** — all database access. Components call these
  functions rather than querying Supabase directly.
- **`src/middleware.ts`** — refreshes the Supabase session and blocks
  unauthenticated access to `/applicant`, `/student`, `/parent`. This is a
  first line of defense only: Row Level Security in
  `supabase/migrations/0001_init.sql` is what actually prevents one user
  from reading another's data, even if a route check were ever bypassed.

## User types

Applicant, Student and Parent/Guardian all sign in through the same
`/login`. **Role is never self-selected.** A user is a Student only if a
row exists for them in `public.students` (created from authoritative ARC
records, not by the user). A user is a Parent only for students explicitly
linked via `public.parent_student_links`, which is written exclusively by
the service role from your back-office system — there is no "add a
student" self-service flow in this portal by design.

## Local development

```bash
npm install
cp .env.example .env.local   # fill in Supabase values, see below
npm run dev
```

## Supabase setup

1. Create a Supabase project.
2. In the SQL editor (or via `supabase db push` with the CLI), run
   `supabase/migrations/0001_init.sql`. It creates all tables, RLS
   policies, the `arc-documents` private storage bucket, and the
   `submit_application` function that assigns the authoritative
   application ID.
3. Copy your project URL and anon key into `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...   # server-only, never exposed to the browser
   ```
4. Populate `public.students` and `public.parent_student_links` from your
   authoritative ARC records (admissions/registrar system) — not from this
   portal's UI, which has no such write path by design.

## Environment variables

See `.env.example`. Notably:

- `NEXT_PUBLIC_SITE_URL` / `NEXT_PUBLIC_PORTAL_URL` — set to your Vercel
  deployment URL for now (e.g. `https://arc-portal.vercel.app`). No real
  custom domain has been purchased yet, so none is hardcoded anywhere in
  this codebase. When the domain is bought, update these two variables in
  Vercel's project settings and redeploy — no code changes needed.

## Production build

```bash
npm run build
npm start
```

## Deploying — GitHub + Vercel (no Codespaces, no Docker required)

1. **Create a GitHub repository** (empty, no template).
2. **Upload the project files** — either `git init && git add . && git
   commit -m "Initial ARC Portal" && git remote add origin <repo-url> &&
   git push -u origin main`, or use GitHub's web "Upload files" if you
   prefer not to use git locally.
3. **Import the repo into Vercel** (vercel.com → New Project → select the
   repo). Vercel auto-detects Next.js — no custom build config needed.
4. **Add environment variables** in the Vercel project's Settings →
   Environment Variables: all the values from `.env.example` above.
5. **Deploy.** Vercel gives you a URL like `https://arc-portal-xyz.vercel.app`.
6. **Set `NEXT_PUBLIC_SITE_URL` and `NEXT_PUBLIC_PORTAL_URL`** to that exact
   URL in Vercel's env vars, then redeploy (env var changes require a
   redeploy to take effect).
7. **Connect the public ARC website** (`arc.edu.ng`) — update its "Apply",
   "ARC Portal" and "Student Portal" buttons/links to point at that Vercel
   URL. Do not build `/apply` or `/student-portal` pages on arc.edu.ng
   itself.
8. **Later, once a custom domain is purchased:** add it in Vercel's
   Domains settings, point its DNS at Vercel, then update
   `NEXT_PUBLIC_SITE_URL` / `NEXT_PUBLIC_PORTAL_URL` to the new domain and
   redeploy. Also update the links on arc.edu.ng to the new domain. No
   application code changes are required for this transition.

## Security considerations

- Every table in `supabase/migrations/0001_init.sql` has Row Level
  Security enabled with narrow, ownership-based policies — no policy
  allows one applicant/student/parent to read another's records.
- The `arc-documents` storage bucket is private; documents are served only
  via short-lived signed URLs (`getSignedDocumentUrl`), never public paths.
- The service role key must only ever be set as a server-side environment
  variable in Vercel — never in `NEXT_PUBLIC_*`, never committed to git.
- `middleware.ts` blocks unauthenticated requests to portal routes, but
  authorization (role-correctness, record ownership) is enforced again at
  the data layer via RLS — treat the middleware check as a UX convenience,
  not the security boundary.
