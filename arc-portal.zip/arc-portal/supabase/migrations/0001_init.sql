-- ARC Portal — initial schema
-- Run this against your ARC Supabase project (e.g. via `supabase db push`
-- or the SQL editor). This is a starting schema for the PORTAL's own
-- read/write needs; if ARC already has an authoritative back-office
-- database, prefer syncing/mirroring into these tables rather than
-- treating this as the system of record for students/results/fees.

-- ─────────────────────────────────────────────────────────────────────────
-- Extensions
-- ─────────────────────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";

-- ─────────────────────────────────────────────────────────────────────────
-- profiles — one row per authenticated user (mirrors auth.users)
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  email text not null,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, new.raw_user_meta_data ->> 'full_name', new.email);
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;

create policy "profiles: read own"
  on public.profiles for select
  using (auth.uid() = id);

create policy "profiles: update own"
  on public.profiles for update
  using (auth.uid() = id);

-- ─────────────────────────────────────────────────────────────────────────
-- applications
-- ─────────────────────────────────────────────────────────────────────────
create type public.application_status as enum (
  'draft', 'submitted', 'payment_pending', 'payment_confirmed', 'under_review',
  'assessment_pending', 'assessment_completed', 'admission_processing',
  'admitted', 'not_admitted', 'withdrawn', 'flagged', 'rescheduled'
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  application_id text unique, -- assigned authoritatively on submission
  applicant_id uuid not null references public.profiles (id) on delete cascade,
  division text,
  segment text,
  schooling_option text,
  status public.application_status not null default 'draft',
  personal_data jsonb,
  submitted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists applications_set_updated_at on public.applications;
create trigger applications_set_updated_at
  before update on public.applications
  for each row execute procedure public.set_updated_at();

alter table public.applications enable row level security;

create policy "applications: applicant reads own"
  on public.applications for select
  using (auth.uid() = applicant_id);

create policy "applications: applicant inserts own"
  on public.applications for insert
  with check (auth.uid() = applicant_id);

create policy "applications: applicant updates own draft"
  on public.applications for update
  using (auth.uid() = applicant_id and status = 'draft');

-- Authoritative application ID generator + submit transition.
-- Format: YEAR + TERM + 5 DIGITS + 3 LETTERS, e.g. 2026T158355GHY
-- NOTE: confirm exact term-numbering and letter-generation rules with ARC
-- admissions before go-live — this is a reasonable placeholder scheme.
create sequence if not exists public.application_id_seq;

create or replace function public.submit_application(p_application_id uuid)
returns void as $$
declare
  v_year text := to_char(now(), 'YYYY');
  v_term text := '1'; -- TODO: derive from current admissions term/session config
  v_seq text := lpad((nextval('public.application_id_seq') % 100000)::text, 5, '0');
  v_letters text := upper(substr(md5(random()::text), 1, 3));
  v_formatted text;
begin
  select (v_year || 'T' || v_term || v_seq || v_letters) into v_formatted;

  update public.applications
  set application_id = v_formatted,
      status = 'submitted',
      submitted_at = now()
  where id = p_application_id
    and applicant_id = auth.uid()
    and status = 'draft';

  if not found then
    raise exception 'Application not found, not owned by caller, or not in draft status';
  end if;
end;
$$ language plpgsql security definer;

-- ─────────────────────────────────────────────────────────────────────────
-- students
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_id text unique not null, -- ARC + YEAR + TERM + 3 DIGITS, e.g. ARC26T1736
  profile_id uuid unique not null references public.profiles (id) on delete cascade,
  division text not null,
  class_name text,
  session text,
  created_at timestamptz not null default now()
);

alter table public.students enable row level security;

create policy "students: read own"
  on public.students for select
  using (auth.uid() = profile_id);

-- ─────────────────────────────────────────────────────────────────────────
-- parent_student_links — created only by authorized ARC staff (service role),
-- never self-service by parents.
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.parent_student_links (
  id uuid primary key default gen_random_uuid(),
  parent_profile_id uuid not null references public.profiles (id) on delete cascade,
  student_id uuid not null references public.students (id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (parent_profile_id, student_id)
);

alter table public.parent_student_links enable row level security;

create policy "parent_student_links: parent reads own links"
  on public.parent_student_links for select
  using (auth.uid() = parent_profile_id);

-- No insert/update/delete policy is defined for authenticated users:
-- links are managed exclusively via the service role from the authorized
-- ARC back-office system.

-- ─────────────────────────────────────────────────────────────────────────
-- academic_results
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.academic_results (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  session text not null,
  term text not null,
  subject text not null,
  score numeric,
  grade text,
  remarks text,
  created_at timestamptz not null default now()
);

alter table public.academic_results enable row level security;

create policy "academic_results: student reads own"
  on public.academic_results for select
  using (
    student_id in (select id from public.students where profile_id = auth.uid())
  );

create policy "academic_results: linked parent reads"
  on public.academic_results for select
  using (
    student_id in (
      select student_id from public.parent_student_links where parent_profile_id = auth.uid()
    )
  );

-- ─────────────────────────────────────────────────────────────────────────
-- fees
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.fees (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete cascade,
  fee_item text not null,
  amount numeric not null,
  status text not null default 'unpaid' check (status in ('unpaid', 'paid', 'partial', 'waived')),
  payment_reference text,
  payment_date date,
  receipt_url text,
  created_at timestamptz not null default now()
);

alter table public.fees enable row level security;

create policy "fees: student reads own"
  on public.fees for select
  using (
    student_id in (select id from public.students where profile_id = auth.uid())
  );

create policy "fees: linked parent reads"
  on public.fees for select
  using (
    student_id in (
      select student_id from public.parent_student_links where parent_profile_id = auth.uid()
    )
  );

-- ─────────────────────────────────────────────────────────────────────────
-- documents (metadata; actual files live in Supabase Storage, private bucket)
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles (id) on delete cascade,
  label text not null,
  storage_path text not null,
  created_at timestamptz not null default now()
);

alter table public.documents enable row level security;

create policy "documents: owner reads own"
  on public.documents for select
  using (auth.uid() = owner_id);

create policy "documents: owner inserts own"
  on public.documents for insert
  with check (auth.uid() = owner_id);

-- Private storage bucket for documents. Access is via signed URLs only
-- (see src/lib/services/documents.ts) — never make this bucket public.
insert into storage.buckets (id, name, public)
values ('arc-documents', 'arc-documents', false)
on conflict (id) do nothing;

create policy "arc-documents: owner reads own files"
  on storage.objects for select
  using (bucket_id = 'arc-documents' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "arc-documents: owner uploads own files"
  on storage.objects for insert
  with check (bucket_id = 'arc-documents' and (storage.foldername(name))[1] = auth.uid()::text);

-- ─────────────────────────────────────────────────────────────────────────
-- notices
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.notices (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text,
  content text not null,
  audience text not null check (audience in ('applicants', 'students', 'parents', 'all')),
  published_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.notices enable row level security;

-- Notices are readable by any authenticated portal user once published;
-- writing notices happens from an authorized back-office context (service
-- role), not from this portal.
create policy "notices: authenticated users read published"
  on public.notices for select
  using (auth.role() = 'authenticated' and published_at is not null);

-- ─────────────────────────────────────────────────────────────────────────
-- audit_events — minimal audit trail scaffold
-- ─────────────────────────────────────────────────────────────────────────
create table if not exists public.audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles (id),
  event_type text not null,
  metadata jsonb,
  created_at timestamptz not null default now()
);

alter table public.audit_events enable row level security;
-- No select/insert policies for authenticated users: audit_events is
-- written and read only via the service role.
