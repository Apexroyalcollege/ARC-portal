import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        "arc-navy": "#0A1F44",
        "arc-royal": "#1E3A8A",
        "arc-gold": "#C9A227",
        "arc-cream": "#FAF7F0",
      },
      fontFamily: {
        serif: ["Georgia", "Cambria", "'Times New Roman'", "serif"],
      },
    },
  },
  plugins: [],
};
export default config;
