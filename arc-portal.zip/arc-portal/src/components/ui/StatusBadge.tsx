import type { ApplicationStatus } from "@/lib/config/statuses";
import { APPLICATION_STATUS_LABELS } from "@/lib/config/statuses";

const NEUTRAL = "bg-slate-100 text-slate-700";
const POSITIVE = "bg-emerald-100 text-emerald-700";
const WARNING = "bg-amber-100 text-amber-800";
const NEGATIVE = "bg-rose-100 text-rose-700";

const COLOR_BY_STATUS: Record<ApplicationStatus, string> = {
  draft: NEUTRAL,
  submitted: NEUTRAL,
  payment_pending: WARNING,
  payment_confirmed: POSITIVE,
  under_review: NEUTRAL,
  assessment_pending: WARNING,
  assessment_completed: NEUTRAL,
  admission_processing: NEUTRAL,
  admitted: POSITIVE,
  not_admitted: NEGATIVE,
  withdrawn: NEUTRAL,
  flagged: WARNING,
  rescheduled: WARNING,
};

export function StatusBadge({ status }: { status: ApplicationStatus }) {
  return (
    <span className={`inline-block rounded-full px-3 py-1 text-xs font-medium ${COLOR_BY_STATUS[status]}`}>
      {APPLICATION_STATUS_LABELS[status]}
    </span>
  );
}
