import Link from "next/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "primary" | "secondary" | "ghost";

const VARIANT_CLASSES: Record<Variant, string> = {
  primary:
    "bg-arc-royal text-white hover:bg-arc-navy focus-visible:ring-arc-gold",
  secondary:
    "bg-arc-gold text-arc-navy hover:brightness-95 focus-visible:ring-arc-navy",
  ghost:
    "bg-transparent text-arc-navy border border-arc-navy/30 hover:bg-arc-navy/5 focus-visible:ring-arc-navy",
};

const base =
  "inline-flex items-center justify-center rounded-md px-5 py-2.5 text-sm font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none";

export function Button({
  variant = "primary",
  className = "",
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; children: ReactNode }) {
  return (
    <button className={`${base} ${VARIANT_CLASSES[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function ButtonLink({
  href,
  variant = "primary",
  className = "",
  children,
}: {
  href: string;
  variant?: Variant;
  className?: string;
  children: ReactNode;
}) {
  return (
    <Link href={href} className={`${base} ${VARIANT_CLASSES[variant]} ${className}`}>
      {children}
    </Link>
  );
}
