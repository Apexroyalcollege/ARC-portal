export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <div className="rounded-lg border border-dashed border-arc-navy/20 bg-white/50 px-6 py-10 text-center">
      <p className="font-medium text-arc-navy">{title}</p>
      {description && <p className="mt-1 text-sm text-arc-navy/60">{description}</p>}
    </div>
  );
}
