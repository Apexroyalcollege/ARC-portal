import Link from "next/link";
import { SITE } from "@/lib/config/site";

export function Header() {
  return (
    <header className="border-b border-arc-navy/10 bg-arc-navy text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="flex flex-col leading-tight">
          <span className="font-serif text-lg font-semibold tracking-wide">
            {SITE.institution}
          </span>
          <span className="text-xs uppercase tracking-[0.2em] text-arc-gold">
            {SITE.name}
          </span>
        </Link>
        <nav className="hidden gap-6 text-sm sm:flex">
          <Link href="/login" className="hover:text-arc-gold">
            Log in
          </Link>
          <Link href="/register" className="hover:text-arc-gold">
            Start Application
          </Link>
          <Link href="/help" className="hover:text-arc-gold">
            Help
          </Link>
        </nav>
      </div>
    </header>
  );
}
