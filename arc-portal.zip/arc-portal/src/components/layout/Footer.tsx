import { SITE } from "@/lib/config/site";

export function Footer() {
  return (
    <footer className="border-t border-arc-navy/10 bg-white">
      <div className="mx-auto max-w-6xl px-4 py-6 text-sm text-arc-navy/60">
        <p>
          &copy; {new Date().getFullYear()} {SITE.institution}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
