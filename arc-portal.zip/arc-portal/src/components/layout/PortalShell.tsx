import type { ReactNode } from "react";
import Link from "next/link";
import { SITE } from "@/lib/config/site";
import type { NavItem } from "@/lib/config/navigation";

/**
 * Shared authenticated-area shell for /applicant, /student and /parent.
 * Provides a persistent sidebar on desktop and a simple top nav on mobile.
 */
export function PortalShell({
  nav,
  children,
}: {
  nav: NavItem[];
  children: ReactNode;
}) {
  return (
    <div className="min-h-screen bg-arc-cream">
      <div className="border-b border-arc-navy/10 bg-arc-navy px-4 py-3 text-white sm:hidden">
        <span className="font-serif font-semibold">{SITE.name}</span>
      </div>
      <div className="mx-auto flex max-w-6xl">
        <aside className="hidden w-56 shrink-0 border-r border-arc-navy/10 bg-white p-4 sm:block">
          <nav className="flex flex-col gap-1">
            {nav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-md px-3 py-2 text-sm text-arc-navy hover:bg-arc-navy/5"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>
        <main className="min-w-0 flex-1 p-4 sm:p-8">{children}</main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 flex justify-around border-t border-arc-navy/10 bg-white py-2 sm:hidden">
        {nav.slice(0, 4).map((item) => (
          <Link key={item.href} href={item.href} className="px-2 text-xs text-arc-navy">
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
