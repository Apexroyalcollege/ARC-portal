import type { DivisionId } from "@/lib/config/divisions";
import type { SchoolingOption } from "@/lib/config/schooling";
import type { SegmentId } from "@/lib/config/segments";
import type { ApplicationStatus } from "@/lib/config/statuses";

export type UserRole = "applicant" | "student" | "parent";

export interface Profile {
  id: string;
  full_name: string | null;
  email: string;
  created_at: string;
}

export interface Application {
  id: string;
  application_id: string; // authoritative formatted ID, e.g. 2026T158355GHY
  applicant_id: string;
  division: DivisionId;
  segment: SegmentId | null;
  schooling_option: SchoolingOption;
  status: ApplicationStatus;
  personal_data: Record<string, unknown> | null;
  submitted_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Student {
  id: string;
  student_id: string; // authoritative formatted ID, e.g. ARC26T1736
  profile_id: string;
  division: DivisionId;
  class_name: string | null;
  session: string | null;
}

export interface AcademicResult {
  id: string;
  student_id: string;
  session: string;
  term: string;
  subject: string;
  score: number | null;
  grade: string | null;
  remarks: string | null;
}

export interface FeeRecord {
  id: string;
  student_id: string;
  fee_item: string;
  amount: number;
  status: "unpaid" | "paid" | "partial" | "waived";
  payment_reference: string | null;
  payment_date: string | null;
  receipt_url: string | null;
}

export interface Notice {
  id: string;
  title: string;
  category: string;
  content: string;
  audience: "applicants" | "students" | "parents" | "all";
  published_at: string | null;
}

export interface DocumentRecord {
  id: string;
  owner_id: string;
  label: string;
  storage_path: string;
  created_at: string;
}
