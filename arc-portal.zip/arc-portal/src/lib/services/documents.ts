import { createClient } from "@/lib/supabase/server";
import type { DocumentRecord } from "@/types";

const DOCUMENTS_BUCKET = "arc-documents"; // private bucket — see migrations

export async function getMyDocuments(): Promise<DocumentRecord[]> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("documents")
    .select("*")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("getMyDocuments error", error);
    return [];
  }
  return data as DocumentRecord[];
}

/** Returns a short-lived signed URL so private documents are never public. */
export async function getSignedDocumentUrl(storagePath: string, expiresInSeconds = 60) {
  const supabase = await createClient();
  const { data, error } = await supabase.storage
    .from(DOCUMENTS_BUCKET)
    .createSignedUrl(storagePath, expiresInSeconds);

  if (error) {
    console.error("getSignedDocumentUrl error", error);
    return null;
  }
  return data.signedUrl;
}
