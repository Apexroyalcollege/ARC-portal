import { createClient } from "@/lib/supabase/server";
import type { FeeRecord } from "@/types";

export async function getFeesForStudent(studentId: string): Promise<FeeRecord[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("fees")
    .select("*")
    .eq("student_id", studentId)
    .order("payment_date", { ascending: false });

  if (error) {
    console.error("getFeesForStudent error", error);
    return [];
  }
  return data as FeeRecord[];
}

/**
 * Placeholder for a real payment provider integration (e.g. Paystack,
 * Flutterwave, Remita — whichever ARC approves). Secret keys must live
 * only in server environment variables and never be referenced from
 * client components. This function intentionally does not fabricate a
 * successful payment.
 */
export async function initiateApplicationPayment(applicationId: string) {
  throw new Error(
    "Payment provider not yet configured. Integrate an approved payment " +
      "provider here using server-only credentials before enabling this flow."
  );
}
