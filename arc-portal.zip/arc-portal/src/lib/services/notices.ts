import { createClient } from "@/lib/supabase/server";
import type { Notice } from "@/types";

export async function getNoticesForAudience(
  audience: "applicants" | "students" | "parents"
): Promise<Notice[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("notices")
    .select("*")
    .in("audience", [audience, "all"])
    .not("published_at", "is", null)
    .order("published_at", { ascending: false })
    .limit(20);

  if (error) {
    console.error("getNoticesForAudience error", error);
    return [];
  }
  return data as Notice[];
}
