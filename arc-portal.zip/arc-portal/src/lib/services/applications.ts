import { createClient } from "@/lib/supabase/server";
import type { Application } from "@/types";
import type { DivisionId } from "@/lib/config/divisions";
import type { SchoolingOption } from "@/lib/config/schooling";
import type { SegmentId } from "@/lib/config/segments";

/**
 * All database access for applications is centralized here. Components
 * and route handlers should call these functions rather than querying
 * Supabase directly, so the applicant-facing rules (RLS aside) live in
 * one place.
 */

export async function getMyApplication(): Promise<Application | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("applications")
    .select("*")
    .eq("applicant_id", user.id)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error("getMyApplication error", error);
    return null;
  }
  return data as Application | null;
}

export async function createDraftApplication(): Promise<Application | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  // The formatted application_id (YEAR+TERM+5 DIGITS+3 LETTERS) is assigned
  // authoritatively by a database trigger/function on submission — see
  // supabase/migrations. It is intentionally left null on draft creation.
  const { data, error } = await supabase
    .from("applications")
    .insert({ applicant_id: user.id, status: "draft" })
    .select("*")
    .single();

  if (error) {
    console.error("createDraftApplication error", error);
    return null;
  }
  return data as Application;
}

export async function updateApplicationSection(
  applicationId: string,
  patch: Partial<{
    division: DivisionId;
    segment: SegmentId | null;
    schooling_option: SchoolingOption;
    personal_data: Record<string, unknown>;
  }>
) {
  const supabase = await createClient();
  const { error } = await supabase
    .from("applications")
    .update(patch)
    .eq("id", applicationId);

  if (error) console.error("updateApplicationSection error", error);
  return !error;
}

export async function submitApplication(applicationId: string) {
  const supabase = await createClient();
  // Calls a Postgres function (assign_application_id) which generates the
  // authoritative application_id server-side and flips status to
  // "submitted" atomically. See supabase/migrations/0001_init.sql.
  const { error } = await supabase.rpc("submit_application", {
    p_application_id: applicationId,
  });
  if (error) console.error("submitApplication error", error);
  return !error;
}
