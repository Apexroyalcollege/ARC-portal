import { createClient } from "@/lib/supabase/server";
import type { AcademicResult } from "@/types";

export async function getResultsForStudent(studentId: string): Promise<AcademicResult[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("academic_results")
    .select("*")
    .eq("student_id", studentId)
    .order("session", { ascending: false })
    .order("term", { ascending: false });

  if (error) {
    console.error("getResultsForStudent error", error);
    return [];
  }
  return data as AcademicResult[];
}
