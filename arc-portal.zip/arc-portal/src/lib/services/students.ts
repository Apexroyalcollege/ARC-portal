import { createClient } from "@/lib/supabase/server";
import type { Student } from "@/types";

export async function getMyStudentRecord(): Promise<Student | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("students")
    .select("*")
    .eq("profile_id", user.id)
    .maybeSingle();

  if (error) {
    console.error("getMyStudentRecord error", error);
    return null;
  }
  return data as Student | null;
}

/**
 * Returns the students a signed-in parent is authorized to view, based on
 * the parent_student_links table. A parent can never search for or view
 * a student they are not explicitly linked to — that link is created by
 * authorized ARC staff, never by the parent themselves.
 */
export async function getLinkedStudentsForParent(): Promise<Student[]> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from("parent_student_links")
    .select("students(*)")
    .eq("parent_profile_id", user.id);

  if (error) {
    console.error("getLinkedStudentsForParent error", error);
    return [];
  }
  return (data ?? []).flatMap((row: any) => (row.students ? [row.students] : []));
}
