/**
 * The four ARC divisions. This is the single source of truth — do not
 * hardcode division names anywhere else in the app.
 */
export type DivisionId =
  | "royal-newbies"
  | "apex-royal-trailblazer"
  | "apex-royal-cadet"
  | "institute-of-excellence";

export interface Division {
  id: DivisionId;
  name: string;
  hasSegments: boolean;
}

export const DIVISIONS: Division[] = [
  { id: "royal-newbies", name: "Royal Newbies", hasSegments: false },
  { id: "apex-royal-trailblazer", name: "Apex Royal Trailblazer", hasSegments: false },
  { id: "apex-royal-cadet", name: "Apex Royal Cadet", hasSegments: false },
  {
    id: "institute-of-excellence",
    name: "Institute of Excellence, APEX ROYAL COLLEGE",
    hasSegments: true,
  },
];

export function getDivision(id: DivisionId | string | undefined | null) {
  return DIVISIONS.find((d) => d.id === id);
}
