import type { DivisionId } from "./divisions";

export type SchoolingOption = "day" | "boarding";

export const SCHOOLING_LABELS: Record<SchoolingOption, string> = {
  day: "Day",
  boarding: "Boarding",
};

/**
 * Which schooling options are valid for each division. The UI must only
 * ever offer options returned from here — never hardcode this elsewhere.
 */
const SCHOOLING_RULES: Record<DivisionId, SchoolingOption[]> = {
  "royal-newbies": ["day"],
  "apex-royal-trailblazer": ["day"],
  "apex-royal-cadet": ["day", "boarding"],
  "institute-of-excellence": ["day", "boarding"],
};

export function getAvailableSchoolingOptions(division: DivisionId): SchoolingOption[] {
  return SCHOOLING_RULES[division] ?? [];
}

export function isValidSchoolingOption(division: DivisionId, option: string): boolean {
  return getAvailableSchoolingOptions(division).includes(option as SchoolingOption);
}
