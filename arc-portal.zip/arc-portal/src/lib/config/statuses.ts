/**
 * Data-driven application statuses. "Flagged" is a neutral administrative
 * hold state, not an accusation — UI copy referencing it must stay neutral.
 */
export type ApplicationStatus =
  | "draft"
  | "submitted"
  | "payment_pending"
  | "payment_confirmed"
  | "under_review"
  | "assessment_pending"
  | "assessment_completed"
  | "admission_processing"
  | "admitted"
  | "not_admitted"
  | "withdrawn"
  | "flagged"
  | "rescheduled";

export const APPLICATION_STATUS_LABELS: Record<ApplicationStatus, string> = {
  draft: "Draft",
  submitted: "Submitted",
  payment_pending: "Payment Pending",
  payment_confirmed: "Payment Confirmed",
  under_review: "Under Review",
  assessment_pending: "Assessment Pending",
  assessment_completed: "Assessment Completed",
  admission_processing: "Admission Processing",
  admitted: "Admitted",
  not_admitted: "Not Admitted",
  withdrawn: "Withdrawn",
  flagged: "Flagged",
  rescheduled: "Rescheduled",
};

export const APPLICATION_STATUS_EXPLANATIONS: Record<ApplicationStatus, string> = {
  draft: "You have started an application but have not submitted it yet.",
  submitted: "Your application has been submitted and is awaiting payment or review.",
  payment_pending: "Your application fee has not yet been confirmed.",
  payment_confirmed: "Your payment has been confirmed.",
  under_review: "Your application is being reviewed by ARC admissions.",
  assessment_pending: "Your entrance assessment (ARET) has not yet been completed.",
  assessment_completed: "Your entrance assessment has been completed and is being processed.",
  admission_processing: "Your application is in the final stages of the admission decision.",
  admitted: "Congratulations — you have been admitted.",
  not_admitted: "ARC is unable to offer admission at this time.",
  withdrawn: "This application has been withdrawn.",
  flagged: "This application has been placed on an administrative hold pending review. This is a routine status, not a determination of fault.",
  rescheduled: "A step in your application (e.g. assessment) has been rescheduled.",
};
