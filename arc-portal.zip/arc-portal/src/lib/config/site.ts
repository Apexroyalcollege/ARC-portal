export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
export const PORTAL_URL = process.env.NEXT_PUBLIC_PORTAL_URL ?? SITE_URL;

export const SITE = {
  name: "ARC Portal",
  institution: "Apex Royal College",
  shortName: "ARC",
  description: "Admissions, student services and academic access.",
  supportEmail: process.env.NEXT_PUBLIC_SUPPORT_EMAIL ?? "",
  supportPhone: process.env.NEXT_PUBLIC_SUPPORT_PHONE ?? "",
};
