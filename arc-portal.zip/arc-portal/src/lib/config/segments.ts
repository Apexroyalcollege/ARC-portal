/**
 * Institute segments. Only relevant when the "Institute of Excellence"
 * division is selected (see divisions.ts -> hasSegments).
 */
export type SegmentId = "science" | "social-science-business" | "humanities";

export const SEGMENTS: { id: SegmentId; name: string }[] = [
  { id: "science", name: "Science" },
  { id: "social-science-business", name: "Social Science/Business" },
  { id: "humanities", name: "Humanities" },
];

export function getSegment(id: SegmentId | string | undefined | null) {
  return SEGMENTS.find((s) => s.id === id);
}
