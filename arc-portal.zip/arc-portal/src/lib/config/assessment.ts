import type { DivisionId } from "./divisions";
import type { SegmentId } from "./segments";

/**
 * Centralized ARET (Apex Royal Entrance Test) assessment-subject
 * configuration. Nothing outside this file should decide which subjects
 * an applicant is assessed on — components should only ever call
 * getAssessmentSubjects().
 *
 * These subject lists are placeholders (development-only examples) and
 * MUST be reviewed and confirmed by ARC academic administration before
 * go-live.
 */
export interface AssessmentSubjectRule {
  division: DivisionId;
  segment?: SegmentId; // only present for divisions with segments
  subjects: string[];
}

const ASSESSMENT_CONFIG: AssessmentSubjectRule[] = [
  { division: "royal-newbies", subjects: ["Literacy", "Numeracy", "General Knowledge"] },
  {
    division: "apex-royal-trailblazer",
    subjects: ["English Language", "Mathematics", "General Knowledge"],
  },
  {
    division: "apex-royal-cadet",
    subjects: ["English Language", "Mathematics", "Basic Science", "General Knowledge"],
  },
  {
    division: "institute-of-excellence",
    segment: "science",
    subjects: ["English Language", "Mathematics", "Physics", "Chemistry", "Biology"],
  },
  {
    division: "institute-of-excellence",
    segment: "social-science-business",
    subjects: ["English Language", "Mathematics", "Economics", "Government", "Commerce"],
  },
  {
    division: "institute-of-excellence",
    segment: "humanities",
    subjects: ["English Language", "Mathematics", "Literature in English", "Government", "History"],
  },
];

export function getAssessmentSubjects(
  division: DivisionId,
  segment?: SegmentId
): string[] {
  const rule = ASSESSMENT_CONFIG.find(
    (r) => r.division === division && (r.segment ?? undefined) === (segment ?? undefined)
  );
  return rule?.subjects ?? [];
}
