export interface NavItem {
  label: string;
  href: string;
}

export const APPLICANT_NAV: NavItem[] = [
  { label: "Dashboard", href: "/applicant" },
  { label: "Application", href: "/applicant/application" },
  { label: "Status", href: "/applicant/application/status" },
];

export const STUDENT_NAV: NavItem[] = [
  { label: "Dashboard", href: "/student" },
  { label: "Profile", href: "/student/profile" },
  { label: "Academics", href: "/student/academics" },
  { label: "Results", href: "/student/results" },
  { label: "Records", href: "/student/records" },
  { label: "Fees", href: "/student/fees" },
  { label: "Payments", href: "/student/payments" },
  { label: "Documents", href: "/student/documents" },
  { label: "Notices", href: "/student/notices" },
  { label: "Calendar", href: "/student/calendar" },
  { label: "Support", href: "/student/support" },
];

export const PARENT_NAV: NavItem[] = [{ label: "Dashboard", href: "/parent" }];
