import Link from "next/link";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { ButtonLink } from "@/components/ui/Button";
import { APPLICANT_NAV } from "@/lib/config/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { getNoticesForAudience } from "@/lib/services/notices";
import { getDivision } from "@/lib/config/divisions";

const SECTIONS = [
  { key: "personal_data", label: "Bio-data", href: "/applicant/application/personal" },
  { key: "division", label: "ARC Division", href: "/applicant/application/division" },
  { key: "schooling_option", label: "Schooling Option", href: "/applicant/application/schooling" },
];

export default async function ApplicantDashboard() {
  const [application, notices] = await Promise.all([
    getMyApplication(),
    getNoticesForAudience("applicants"),
  ]);

  const division = application ? getDivision(application.division) : undefined;
  const incomplete = application
    ? SECTIONS.filter((s) => !(application as any)[s.key])
    : SECTIONS;

  return (
    <PortalShell nav={APPLICANT_NAV}>
      <h1 className="font-serif text-2xl font-semibold text-arc-navy">
        Welcome{application ? "" : " to ARC Portal"}
      </h1>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Your application" />
          <CardBody>
            {application ? (
              <div className="flex flex-col gap-4">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-sm text-arc-navy/60">Application ID</span>
                  <span className="font-mono text-sm">
                    {application.application_id ?? "Not yet assigned (submit to generate)"}
                  </span>
                  <StatusBadge status={application.status} />
                </div>
                {division && (
                  <p className="text-sm text-arc-navy/70">Division: {division.name}</p>
                )}
                {incomplete.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-arc-navy">Incomplete sections</p>
                    <ul className="mt-1 list-inside list-disc text-sm text-arc-royal">
                      {incomplete.map((s) => (
                        <li key={s.key}>
                          <Link href={s.href} className="hover:underline">
                            {s.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                <div>
                  <ButtonLink href="/applicant/application">Continue application</ButtonLink>
                </div>
              </div>
            ) : (
              <EmptyState
                title="You haven't started an application yet"
                description="Begin your ARC application — it only takes a few minutes to complete the first section."
              />
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Notices" />
          <CardBody>
            {notices.length === 0 ? (
              <EmptyState title="No notices at this time" />
            ) : (
              <ul className="flex flex-col gap-3">
                {notices.map((n) => (
                  <li key={n.id} className="text-sm">
                    <p className="font-medium text-arc-navy">{n.title}</p>
                    <p className="text-arc-navy/60">{n.content}</p>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>

      {!application && (
        <div className="mt-6">
          <ButtonLink href="/applicant/application">Start Application</ButtonLink>
        </div>
      )}
    </PortalShell>
  );
}
