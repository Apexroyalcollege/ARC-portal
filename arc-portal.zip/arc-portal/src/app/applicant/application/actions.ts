"use server";

import { revalidatePath } from "next/cache";
import {
  createDraftApplication,
  getMyApplication,
  submitApplication,
  updateApplicationSection,
} from "@/lib/services/applications";
import type { DivisionId } from "@/lib/config/divisions";
import type { SegmentId } from "@/lib/config/segments";
import type { SchoolingOption } from "@/lib/config/schooling";
import { isValidSchoolingOption } from "@/lib/config/schooling";
import { getDivision } from "@/lib/config/divisions";

export async function ensureApplication() {
  const existing = await getMyApplication();
  if (existing) return existing;
  return createDraftApplication();
}

export async function savePersonalData(applicationId: string, formData: FormData) {
  const personal_data = {
    first_name: String(formData.get("first_name") ?? ""),
    last_name: String(formData.get("last_name") ?? ""),
    date_of_birth: String(formData.get("date_of_birth") ?? ""),
    gender: String(formData.get("gender") ?? ""),
    address: String(formData.get("address") ?? ""),
    phone: String(formData.get("phone") ?? ""),
  };
  await updateApplicationSection(applicationId, { personal_data });
  revalidatePath("/applicant/application/personal");
}

export async function saveDivision(applicationId: string, formData: FormData) {
  const division = String(formData.get("division")) as DivisionId;
  const segmentRaw = formData.get("segment");
  const division_info = getDivision(division);

  await updateApplicationSection(applicationId, {
    division,
    segment: division_info?.hasSegments ? ((segmentRaw as SegmentId) || null) : null,
  });
  revalidatePath("/applicant/application/division");
}

export async function saveSchooling(applicationId: string, division: DivisionId, formData: FormData) {
  const schooling_option = String(formData.get("schooling_option")) as SchoolingOption;
  if (!isValidSchoolingOption(division, schooling_option)) {
    throw new Error("Selected schooling option is not valid for this division.");
  }
  await updateApplicationSection(applicationId, { schooling_option });
  revalidatePath("/applicant/application/schooling");
}

export async function finalizeSubmission(applicationId: string) {
  const ok = await submitApplication(applicationId);
  if (!ok) throw new Error("Could not submit application. Please try again.");
  revalidatePath("/applicant");
}
