import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { StepShell } from "../_StepShell";
import { DivisionForm } from "./DivisionForm";

export default async function DivisionStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");

  return (
    <StepShell step={2} title="ARC Division">
      <DivisionForm
        applicationId={application.id}
        initialDivision={application.division ?? null}
        initialSegment={application.segment ?? null}
      />
    </StepShell>
  );
}
