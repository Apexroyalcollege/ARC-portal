"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { DIVISIONS, type DivisionId } from "@/lib/config/divisions";
import { SEGMENTS, type SegmentId } from "@/lib/config/segments";
import { Button } from "@/components/ui/Button";
import { saveDivision } from "../actions";

export function DivisionForm({
  applicationId,
  initialDivision,
  initialSegment,
}: {
  applicationId: string;
  initialDivision: DivisionId | null;
  initialSegment: SegmentId | null;
}) {
  const router = useRouter();
  const [divisionId, setDivisionId] = useState<string>(initialDivision ?? "");
  const [error, setError] = useState<string | null>(null);
  const selected = DIVISIONS.find((d) => d.id === divisionId);

  async function handleSubmit(formData: FormData) {
    setError(null);
    try {
      await saveDivision(applicationId, formData);
      router.push("/applicant/application/schooling");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      <div>
        <label className="mb-1 block text-sm font-medium text-arc-navy">Select your division</label>
        <div className="flex flex-col gap-2">
          {DIVISIONS.map((d) => (
            <label
              key={d.id}
              className="flex cursor-pointer items-center gap-3 rounded-md border border-arc-navy/15 px-3 py-2 text-sm has-[:checked]:border-arc-royal has-[:checked]:bg-arc-royal/5"
            >
              <input
                type="radio"
                name="division"
                value={d.id}
                checked={divisionId === d.id}
                onChange={() => setDivisionId(d.id)}
                required
              />
              {d.name}
            </label>
          ))}
        </div>
      </div>

      {selected?.hasSegments && (
        <div>
          <label className="mb-1 block text-sm font-medium text-arc-navy">Segment</label>
          <select
            name="segment"
            required
            defaultValue={initialSegment ?? ""}
            className="w-full rounded-md border border-arc-navy/20 px-3 py-2 text-sm"
          >
            <option value="">Select…</option>
            {SEGMENTS.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
      )}

      {error && <p className="text-sm text-rose-600">{error}</p>}
      <div className="pt-2">
        <Button type="submit" disabled={!divisionId}>
          Save and continue
        </Button>
      </div>
    </form>
  );
}
