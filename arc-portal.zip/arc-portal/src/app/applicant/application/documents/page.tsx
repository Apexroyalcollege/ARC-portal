import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { getMyDocuments } from "@/lib/services/documents";
import { ButtonLink } from "@/components/ui/Button";
import { EmptyState } from "@/components/ui/EmptyState";
import { StepShell } from "../_StepShell";

export default async function DocumentsStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");

  const documents = await getMyDocuments();

  return (
    <StepShell step={5} title="Documents">
      <p className="text-sm text-arc-navy/70">
        Upload any documents required for your application (e.g. passport photograph, birth
        certificate, previous school report). Document upload wiring to Supabase Storage should
        be completed against your ARC document checklist.
      </p>
      <div className="mt-4">
        {documents.length === 0 ? (
          <EmptyState title="No documents uploaded yet" />
        ) : (
          <ul className="text-sm">
            {documents.map((d) => (
              <li key={d.id}>{d.label}</li>
            ))}
          </ul>
        )}
      </div>
      <div className="mt-6">
        <ButtonLink href="/applicant/application/payment">Continue</ButtonLink>
      </div>
    </StepShell>
  );
}
