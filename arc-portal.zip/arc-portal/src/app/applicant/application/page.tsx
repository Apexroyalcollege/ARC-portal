import { redirect } from "next/navigation";
import { ensureApplication } from "./actions";

/**
 * Entry point for the application wizard. Ensures a draft application
 * exists, then routes the applicant to the first incomplete step.
 */
export default async function ApplicationEntry() {
  const application = await ensureApplication();
  if (!application) redirect("/login");

  if (!application.personal_data) redirect("/applicant/application/personal");
  if (!application.division) redirect("/applicant/application/division");
  if (!application.schooling_option) redirect("/applicant/application/schooling");
  redirect("/applicant/application/review");
}
