"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { finalizeSubmission } from "../actions";

export function ReviewActions({ applicationId }: { applicationId: string }) {
  const router = useRouter();
  const [declared, setDeclared] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit() {
    setLoading(true);
    setError(null);
    try {
      await finalizeSubmission(applicationId);
      router.push("/applicant/application/status");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not submit application.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-6 flex flex-col gap-4">
      <label className="flex items-start gap-3 text-sm text-arc-navy">
        <input
          type="checkbox"
          checked={declared}
          onChange={(e) => setDeclared(e.target.checked)}
          className="mt-1"
        />
        I declare that the information provided in this application is accurate and complete to
        the best of my knowledge.
      </label>
      {error && <p className="text-sm text-rose-600">{error}</p>}
      <div>
        <Button onClick={handleSubmit} disabled={!declared || loading}>
          {loading ? "Submitting…" : "Submit application"}
        </Button>
      </div>
    </div>
  );
}
