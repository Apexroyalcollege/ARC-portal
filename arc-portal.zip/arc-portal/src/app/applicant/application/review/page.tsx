import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { getDivision } from "@/lib/config/divisions";
import { getSegment } from "@/lib/config/segments";
import { SCHOOLING_LABELS } from "@/lib/config/schooling";
import { StepShell } from "../_StepShell";
import { ReviewActions } from "./ReviewActions";

export default async function ReviewStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");
  if (!application.division) redirect("/applicant/application/division");
  if (!application.schooling_option) redirect("/applicant/application/schooling");

  const personal = (application.personal_data ?? {}) as Record<string, string>;
  const division = getDivision(application.division);
  const segment = application.segment ? getSegment(application.segment) : undefined;

  if (application.status !== "draft") {
    redirect("/applicant/application/status");
  }

  return (
    <StepShell step={7} title="Review &amp; Declaration">
      <dl className="grid gap-3 text-sm sm:grid-cols-2">
        <Row label="Name" value={`${personal.first_name ?? ""} ${personal.last_name ?? ""}`.trim()} />
        <Row label="Date of birth" value={personal.date_of_birth} />
        <Row label="Division" value={division?.name} />
        {segment && <Row label="Segment" value={segment.name} />}
        <Row label="Schooling option" value={SCHOOLING_LABELS[application.schooling_option]} />
      </dl>
      <ReviewActions applicationId={application.id} />
    </StepShell>
  );
}

function Row({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <dt className="text-arc-navy/50">{label}</dt>
      <dd className="font-medium text-arc-navy">{value || "—"}</dd>
    </div>
  );
}
