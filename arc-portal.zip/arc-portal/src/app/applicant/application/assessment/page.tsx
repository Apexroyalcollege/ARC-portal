import { redirect } from "next/navigation";
import Link from "next/link";
import { getMyApplication } from "@/lib/services/applications";
import { getAssessmentSubjects } from "@/lib/config/assessment";
import { getDivision } from "@/lib/config/divisions";
import { getSegment } from "@/lib/config/segments";
import { Button, ButtonLink } from "@/components/ui/Button";
import { StepShell } from "../_StepShell";

export default async function AssessmentStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");
  if (!application.division) redirect("/applicant/application/division");
  if (!application.schooling_option) redirect("/applicant/application/schooling");

  const division = getDivision(application.division);
  const segment = application.segment ? getSegment(application.segment) : undefined;
  const subjects = getAssessmentSubjects(application.division, application.segment ?? undefined);

  return (
    <StepShell step={4} title="Assessment Subjects (ARET)">
      <p className="text-sm text-arc-navy/70">
        Based on {division?.name}
        {segment ? ` — ${segment.name}` : ""}, you will be assessed in the Apex Royal Entrance
        Test (ARET) on the following subjects:
      </p>
      <ul className="mt-4 list-inside list-disc text-sm text-arc-navy">
        {subjects.map((s) => (
          <li key={s}>{s}</li>
        ))}
      </ul>
      <div className="mt-6">
        <ButtonLink href="/applicant/application/documents">Continue</ButtonLink>
      </div>
    </StepShell>
  );
}
