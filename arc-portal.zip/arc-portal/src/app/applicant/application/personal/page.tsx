import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { savePersonalData } from "../actions";
import { StepShell } from "../_StepShell";
import { Button } from "@/components/ui/Button";

export default async function PersonalDataStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");
  const data = (application.personal_data ?? {}) as Record<string, string>;

  async function action(formData: FormData) {
    "use server";
    await savePersonalData(application!.id, formData);
    redirect("/applicant/application/division");
  }

  return (
    <StepShell step={1} title="Bio-data">
      <form action={action} className="flex flex-col gap-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="First name" name="first_name" defaultValue={data.first_name} required />
          <Field label="Last name" name="last_name" defaultValue={data.last_name} required />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Date of birth" name="date_of_birth" type="date" defaultValue={data.date_of_birth} required />
          <div>
            <label className="mb-1 block text-sm font-medium text-arc-navy">Gender</label>
            <select
              name="gender"
              defaultValue={data.gender}
              required
              className="w-full rounded-md border border-arc-navy/20 px-3 py-2 text-sm"
            >
              <option value="">Select…</option>
              <option value="female">Female</option>
              <option value="male">Male</option>
            </select>
          </div>
        </div>
        <Field label="Home address" name="address" defaultValue={data.address} required />
        <Field label="Phone number" name="phone" type="tel" defaultValue={data.phone} required />
        <div className="pt-2">
          <Button type="submit">Save and continue</Button>
        </div>
      </form>
    </StepShell>
  );
}

function Field({
  label,
  name,
  type = "text",
  defaultValue,
  required,
}: {
  label: string;
  name: string;
  type?: string;
  defaultValue?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="mb-1 block text-sm font-medium text-arc-navy">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        defaultValue={defaultValue}
        required={required}
        className="w-full rounded-md border border-arc-navy/20 px-3 py-2 text-sm focus:border-arc-royal focus:outline-none"
      />
    </div>
  );
}
