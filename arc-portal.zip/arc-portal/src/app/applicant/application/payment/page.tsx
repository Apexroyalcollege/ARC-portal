import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { ButtonLink } from "@/components/ui/Button";
import { StepShell } from "../_StepShell";

export default async function PaymentStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");

  return (
    <StepShell step={6} title="Payment">
      <p className="text-sm text-arc-navy/70">
        The application fee payment provider has not been connected yet. Once ARC selects and
        approves a payment provider (e.g. Paystack, Flutterwave, Remita), integrate it in{" "}
        <code className="rounded bg-arc-navy/5 px-1">src/lib/services/payments.ts</code> using
        server-only credentials. Applicants will not be able to submit until this is wired.
      </p>
      <div className="mt-6">
        <ButtonLink href="/applicant/application/review" variant="ghost">
          Continue to review (payment integration pending)
        </ButtonLink>
      </div>
    </StepShell>
  );
}
