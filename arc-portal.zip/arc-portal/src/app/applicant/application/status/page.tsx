import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { APPLICATION_STATUS_EXPLANATIONS } from "@/lib/config/statuses";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { APPLICANT_NAV } from "@/lib/config/navigation";

export default async function ApplicationStatusPage() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");

  return (
    <PortalShell nav={APPLICANT_NAV}>
      <div className="mx-auto max-w-2xl">
        <Card>
          <CardHeader title="Application status" />
          <CardBody>
            <div className="flex items-center gap-3">
              <StatusBadge status={application.status} />
              {application.application_id && (
                <span className="font-mono text-sm">{application.application_id}</span>
              )}
            </div>
            <p className="mt-4 text-sm text-arc-navy/70">
              {APPLICATION_STATUS_EXPLANATIONS[application.status]}
            </p>
          </CardBody>
        </Card>
      </div>
    </PortalShell>
  );
}
