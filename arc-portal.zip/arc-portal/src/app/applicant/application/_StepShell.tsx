import type { ReactNode } from "react";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { APPLICANT_NAV } from "@/lib/config/navigation";

const STEPS = ["Bio-data", "Division", "Schooling", "Assessment", "Documents", "Payment", "Review"];

export function StepShell({
  step,
  title,
  children,
}: {
  step: number; // 1-indexed
  title: string;
  children: ReactNode;
}) {
  return (
    <PortalShell nav={APPLICANT_NAV}>
      <div className="mx-auto max-w-2xl">
        <ol className="mb-6 flex flex-wrap gap-x-2 gap-y-1 text-xs text-arc-navy/50">
          {STEPS.map((label, i) => (
            <li key={label} className={i + 1 === step ? "font-semibold text-arc-royal" : ""}>
              {i + 1}. {label}
              {i < STEPS.length - 1 && <span className="mx-1">→</span>}
            </li>
          ))}
        </ol>
        <Card>
          <CardHeader title={title} />
          <CardBody>{children}</CardBody>
        </Card>
      </div>
    </PortalShell>
  );
}
