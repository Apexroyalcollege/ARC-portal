"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { DivisionId } from "@/lib/config/divisions";
import { getAvailableSchoolingOptions, SCHOOLING_LABELS } from "@/lib/config/schooling";
import { Button } from "@/components/ui/Button";
import { saveSchooling } from "../actions";

export function SchoolingForm({
  applicationId,
  division,
  initialOption,
}: {
  applicationId: string;
  division: DivisionId;
  initialOption: string | null;
}) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const options = getAvailableSchoolingOptions(division);

  async function handleSubmit(formData: FormData) {
    setError(null);
    try {
      await saveSchooling(applicationId, division, formData);
      router.push("/applicant/application/assessment");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    }
  }

  return (
    <form action={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-2">
        {options.map((opt) => (
          <label
            key={opt}
            className="flex cursor-pointer items-center gap-3 rounded-md border border-arc-navy/15 px-3 py-2 text-sm has-[:checked]:border-arc-royal has-[:checked]:bg-arc-royal/5"
          >
            <input type="radio" name="schooling_option" value={opt} defaultChecked={initialOption === opt} required />
            {SCHOOLING_LABELS[opt]}
          </label>
        ))}
      </div>
      {error && <p className="text-sm text-rose-600">{error}</p>}
      <div className="pt-2">
        <Button type="submit">Save and continue</Button>
      </div>
    </form>
  );
}
