import { redirect } from "next/navigation";
import { getMyApplication } from "@/lib/services/applications";
import { StepShell } from "../_StepShell";
import { SchoolingForm } from "./SchoolingForm";

export default async function SchoolingStep() {
  const application = await getMyApplication();
  if (!application) redirect("/applicant/application");
  if (!application.division) redirect("/applicant/application/division");

  return (
    <StepShell step={3} title="Schooling Option">
      <SchoolingForm
        applicationId={application.id}
        division={application.division}
        initialOption={application.schooling_option ?? null}
      />
    </StepShell>
  );
}
