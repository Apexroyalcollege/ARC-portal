import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { ButtonLink } from "@/components/ui/Button";
import { SITE } from "@/lib/config/site";

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex flex-1 items-center justify-center px-4 py-16">
        <div className="max-w-2xl text-center">
          <p className="text-sm uppercase tracking-[0.3em] text-arc-gold">
            {SITE.institution}
          </p>
          <h1 className="mt-3 font-serif text-4xl font-semibold text-arc-navy sm:text-5xl">
            {SITE.name}
          </h1>
          <p className="mt-4 text-lg text-arc-navy/70">{SITE.description}</p>

          <div className="mt-10 grid gap-3 sm:grid-cols-2">
            <ButtonLink href="/register" className="w-full">
              Start Application
            </ButtonLink>
            <ButtonLink href="/login" variant="ghost" className="w-full">
              Applicant Login
            </ButtonLink>
            <ButtonLink href="/login?role=student" variant="ghost" className="w-full">
              Student Login
            </ButtonLink>
            <ButtonLink href="/login?role=parent" variant="ghost" className="w-full">
              Parent/Guardian Access
            </ButtonLink>
          </div>

          <div className="mt-6">
            <ButtonLink href="/help" variant="secondary">
              Help / Enquiries
            </ButtonLink>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
