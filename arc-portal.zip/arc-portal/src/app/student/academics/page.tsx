import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { STUDENT_NAV } from "@/lib/config/navigation";
import { getDivision } from "@/lib/config/divisions";

export default async function AcademicsPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const division = getDivision(student.division);

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Academics" />
        <CardBody>
          <dl className="grid gap-3 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-arc-navy/50">Division</dt>
              <dd className="font-medium text-arc-navy">{division?.name ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-arc-navy/50">Class</dt>
              <dd className="font-medium text-arc-navy">{student.class_name ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-arc-navy/50">Session</dt>
              <dd className="font-medium text-arc-navy">{student.session ?? "—"}</dd>
            </div>
          </dl>
        </CardBody>
      </Card>
    </PortalShell>
  );
}
