import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getFeesForStudent } from "@/lib/services/payments";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function FeesPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const fees = await getFeesForStudent(student.id);

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Fees" />
        <CardBody>
          {fees.length === 0 ? (
            <EmptyState title="No fee records on file" />
          ) : (
            <ul className="flex flex-col gap-3 text-sm">
              {fees.map((f) => (
                <li key={f.id} className="flex justify-between border-b border-arc-navy/5 pb-2">
                  <span>{f.fee_item}</span>
                  <span className="font-medium">
                    ₦{f.amount.toLocaleString()} — {f.status}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </PortalShell>
  );
}
