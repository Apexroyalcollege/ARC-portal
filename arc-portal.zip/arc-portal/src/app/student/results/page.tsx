import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getResultsForStudent } from "@/lib/services/results";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function ResultsPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const results = await getResultsForStudent(student.id);

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Results" subtitle="APEX ROYAL COLLEGE — Student Result" />
        <CardBody>
          {results.length === 0 ? (
            <EmptyState
              title="No results published yet"
              description="Results will appear here once your session/term academic records are published."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-arc-navy/10 text-arc-navy/50">
                    <th className="py-2 pr-4">Session</th>
                    <th className="py-2 pr-4">Term</th>
                    <th className="py-2 pr-4">Subject</th>
                    <th className="py-2 pr-4">Score</th>
                    <th className="py-2 pr-4">Grade</th>
                    <th className="py-2">Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((r) => (
                    <tr key={r.id} className="border-b border-arc-navy/5">
                      <td className="py-2 pr-4">{r.session}</td>
                      <td className="py-2 pr-4">{r.term}</td>
                      <td className="py-2 pr-4">{r.subject}</td>
                      <td className="py-2 pr-4">{r.score ?? "—"}</td>
                      <td className="py-2 pr-4">{r.grade ?? "—"}</td>
                      <td className="py-2">{r.remarks ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>
    </PortalShell>
  );
}
