import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function RecordsPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Academic records" />
        <CardBody>
          <EmptyState title="No additional records on file yet" />
        </CardBody>
      </Card>
    </PortalShell>
  );
}
