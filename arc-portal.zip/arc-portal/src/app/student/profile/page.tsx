import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { STUDENT_NAV } from "@/lib/config/navigation";
import { getDivision } from "@/lib/config/divisions";

export default async function StudentProfilePage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const division = getDivision(student.division);

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Profile" />
        <CardBody>
          <dl className="grid gap-3 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-arc-navy/50">Student ID</dt>
              <dd className="font-mono font-medium text-arc-navy">{student.student_id}</dd>
            </div>
            <div>
              <dt className="text-arc-navy/50">Division</dt>
              <dd className="font-medium text-arc-navy">{division?.name ?? "—"}</dd>
            </div>
          </dl>
        </CardBody>
      </Card>
    </PortalShell>
  );
}
