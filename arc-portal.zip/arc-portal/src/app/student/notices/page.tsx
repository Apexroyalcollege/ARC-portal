import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getNoticesForAudience } from "@/lib/services/notices";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function StudentNoticesPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const notices = await getNoticesForAudience("students");

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Notices" />
        <CardBody>
          {notices.length === 0 ? (
            <EmptyState title="No notices at this time" />
          ) : (
            <ul className="flex flex-col gap-3 text-sm">
              {notices.map((n) => (
                <li key={n.id}>
                  <p className="font-medium text-arc-navy">{n.title}</p>
                  <p className="text-arc-navy/60">{n.content}</p>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </PortalShell>
  );
}
