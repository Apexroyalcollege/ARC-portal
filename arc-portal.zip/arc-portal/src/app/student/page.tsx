import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getNoticesForAudience } from "@/lib/services/notices";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";
import { getDivision } from "@/lib/config/divisions";

export default async function StudentDashboard() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");

  const notices = await getNoticesForAudience("students");
  const division = getDivision(student.division);

  return (
    <PortalShell nav={STUDENT_NAV}>
      <h1 className="font-serif text-2xl font-semibold text-arc-navy">Welcome back</h1>
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Student profile" />
          <CardBody>
            <dl className="grid gap-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-arc-navy/50">Student ID</dt>
                <dd className="font-mono font-medium text-arc-navy">{student.student_id}</dd>
              </div>
              <div>
                <dt className="text-arc-navy/50">Division</dt>
                <dd className="font-medium text-arc-navy">{division?.name ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-arc-navy/50">Class</dt>
                <dd className="font-medium text-arc-navy">{student.class_name ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-arc-navy/50">Session</dt>
                <dd className="font-medium text-arc-navy">{student.session ?? "—"}</dd>
              </div>
            </dl>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Notices" />
          <CardBody>
            {notices.length === 0 ? (
              <EmptyState title="No notices at this time" />
            ) : (
              <ul className="flex flex-col gap-3 text-sm">
                {notices.map((n) => (
                  <li key={n.id}>
                    <p className="font-medium text-arc-navy">{n.title}</p>
                    <p className="text-arc-navy/60">{n.content}</p>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </PortalShell>
  );
}
