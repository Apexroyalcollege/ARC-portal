import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getMyDocuments } from "@/lib/services/documents";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function StudentDocumentsPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const documents = await getMyDocuments();

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Documents" />
        <CardBody>
          {documents.length === 0 ? (
            <EmptyState title="No documents available" />
          ) : (
            <ul className="text-sm">
              {documents.map((d) => (
                <li key={d.id}>{d.label}</li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </PortalShell>
  );
}
