import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { STUDENT_NAV } from "@/lib/config/navigation";
import { SITE } from "@/lib/config/site";

export default async function StudentSupportPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Support" />
        <CardBody>
          <p className="text-sm text-arc-navy/70">
            {SITE.supportEmail || "Support email not yet configured."}
            {SITE.supportPhone ? ` · ${SITE.supportPhone}` : ""}
          </p>
        </CardBody>
      </Card>
    </PortalShell>
  );
}
