import { redirect } from "next/navigation";
import { getMyStudentRecord } from "@/lib/services/students";
import { getFeesForStudent } from "@/lib/services/payments";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { STUDENT_NAV } from "@/lib/config/navigation";

export default async function PaymentsPage() {
  const student = await getMyStudentRecord();
  if (!student) redirect("/unauthorized");
  const fees = await getFeesForStudent(student.id);
  const paid = fees.filter((f) => f.status === "paid" || f.status === "partial");

  return (
    <PortalShell nav={STUDENT_NAV}>
      <Card>
        <CardHeader title="Payment history" />
        <CardBody>
          {paid.length === 0 ? (
            <EmptyState title="No payments recorded yet" />
          ) : (
            <ul className="flex flex-col gap-3 text-sm">
              {paid.map((f) => (
                <li key={f.id} className="flex justify-between border-b border-arc-navy/5 pb-2">
                  <span>{f.fee_item}</span>
                  <span className="font-mono text-xs text-arc-navy/60">
                    {f.payment_reference ?? "—"} · {f.payment_date ?? "—"}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </PortalShell>
  );
}
