import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { SITE } from "@/lib/config/site";

const FAQS = [
  {
    q: "How do I start an application?",
    a: "Select \"Start Application\" on the ARC Portal home page, create an account, and follow the guided steps: bio-data, division, schooling option, assessment subjects, declaration and payment.",
  },
  {
    q: "Can I save my application and continue later?",
    a: "Yes. Your application is saved automatically as you complete each section, and you can resume from your applicant dashboard.",
  },
  {
    q: "How do I check my application status?",
    a: "Log in and visit your applicant dashboard, or the Status page under your application, for the current stage of your application.",
  },
];

export default function HelpPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-12">
        <h1 className="font-serif text-3xl font-semibold text-arc-navy">Help &amp; Enquiries</h1>
        <div className="mt-8 flex flex-col gap-6">
          {FAQS.map((item) => (
            <div key={item.q}>
              <h2 className="font-medium text-arc-navy">{item.q}</h2>
              <p className="mt-1 text-sm text-arc-navy/70">{item.a}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 rounded-lg border border-arc-navy/10 bg-white p-5">
          <h2 className="font-medium text-arc-navy">Contact ARC Admissions</h2>
          <p className="mt-1 text-sm text-arc-navy/70">
            {SITE.supportEmail || "Support email not yet configured."}
            {SITE.supportPhone ? ` · ${SITE.supportPhone}` : ""}
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
