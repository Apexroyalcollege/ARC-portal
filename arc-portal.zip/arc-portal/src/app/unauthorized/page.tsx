import { ButtonLink } from "@/components/ui/Button";

export default function UnauthorizedPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-4 text-center">
      <h1 className="font-serif text-2xl font-semibold text-arc-navy">Access restricted</h1>
      <p className="mt-2 text-sm text-arc-navy/70">
        You do not have permission to view this page with your current account.
      </p>
      <ButtonLink href="/" className="mt-6">
        Return to ARC Portal home
      </ButtonLink>
    </div>
  );
}
