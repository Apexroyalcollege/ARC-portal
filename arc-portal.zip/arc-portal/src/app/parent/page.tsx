import { redirect } from "next/navigation";
import { getLinkedStudentsForParent } from "@/lib/services/students";
import { PortalShell } from "@/components/layout/PortalShell";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/EmptyState";
import { PARENT_NAV } from "@/lib/config/navigation";
import { getDivision } from "@/lib/config/divisions";

export default async function ParentDashboard() {
  const students = await getLinkedStudentsForParent();

  return (
    <PortalShell nav={PARENT_NAV}>
      <h1 className="font-serif text-2xl font-semibold text-arc-navy">Linked students</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {students.length === 0 ? (
          <EmptyState
            title="No students linked to your account yet"
            description="Contact ARC administration to have a student record linked to your parent/guardian account."
          />
        ) : (
          students.map((s) => (
            <Card key={s.id}>
              <CardHeader title={s.student_id} />
              <CardBody>
                <p className="text-sm text-arc-navy/70">
                  Division: {getDivision(s.division)?.name ?? "—"}
                </p>
                <p className="text-sm text-arc-navy/70">Class: {s.class_name ?? "—"}</p>
              </CardBody>
            </Card>
          ))
        )}
      </div>
    </PortalShell>
  );
}
